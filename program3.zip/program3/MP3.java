
//Taylor Heatherly

package program3;




public class MP3 extends MP3Player implements Sounds
{
	
	protected String title;
	
	public MP3()
	{
		// TODO Auto-generated constructor stub
	}
	
	
	
	public void play()
	{
		//super.setFileName(filename);
		super.play();
	}
	
	public void play(String fn)
	{
		
	}

	
	

	public void print()
	{
		
		System.out.println("Title:" + this.title);
		System.out.println("FileName: "+ this.fileName);
		

	}


	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String string)
	{
		
		fileName = string;
	}

	public void setTitle(String title) {
		this.title=title;
	}
	public String getTitle() {
		return title;
	}

		
				
	public static void main(String[] args) 
	{
		int counter = 0;
		int countwave = 0;
		int countmp3 = 0;
		String loweredargs;
		int[] index = new int[100];
		
		
		//split
		String[] list = args[0].split(" +");
		String[] mp3s = {"baboon","badger","bear","bees","bison","blackbird","bluejay","bobcat","camel","dog","donkey","eagle","elephant","goat","pig","robin","sheep","bark","drip","glass","hammer","phone","toy"};
		String[] waves = {"airplane","alarm","applause","baby","bomb","chicken","chimes","cow","coyote","crickets","ding","electric","notify","recycle","ringout","saw","drill" };
		String[] Mtitles = {"Baboon Making Noise","Honey Badger","A Black Bear","A Hive of Bees", "Bison Grunting","Blackbirds at night","A Bluejay squaking", "A bobcat", "A camel making noise", "A dog", "A donkey Hee-Haw","An eagle soaring","An elephant doing things", "A goat", "A pig","A singing Robin","A Wooly Sheep", "A dog barking","A dripping faucet","A glass half full","A hammer and nail","A ringing phone","A toy"};
		String[] Wtitles = {"A flying airplane", "An alarm ringing","Applause! Applause!", "A baby - A baby","Dropping Bomb","A chicken crowing","Wind chimes","A hungry cow","A howling coyote","Hear the crickets","Ding Dong","Electrical Current","Notify Me Now","Recycle Now","Phone Ringing","Saw Sounds","An elecric drill"};
		Sounds[] player = new Sounds[100];
		for (int i = 0; i < list.length; i++)
		{
			loweredargs = list[i].toLowerCase();
			countmp3 = 0;
			countwave = 0;
			
			for (int j = 0; j < mp3s.length;j++)
			{
				if (countwave < waves.length)
				{
				  if (loweredargs.indexOf(waves[countwave]) >= 0)
				  {
				  	index[counter] = i;
				  	Wave wav = new Wave();
				  	wav.setFileName("./program3/" + waves[countwave] +".wav");
						player[counter] = wav;
						player[counter].setTitle(Wtitles[countwave]);
						counter++;
						break;
				  }
				  countwave++;
				}  	
				if (countmp3 < mp3s.length)
				{
					if (loweredargs.indexOf(mp3s[countmp3]) >= 0)
					{
						//Allocate info
						index[counter] = i;
						MP3 mp3 = new MP3();
	
						mp3.setFileName("./program3/" + mp3s[countmp3] +".mp3");
						player[counter] = mp3;
						
						//player[counter].setFileName("./program3/" + mp3s[countmp3] +".mp3");
						player[counter].setTitle(Mtitles[countmp3]);
						counter++;
						break;
					}
					countmp3++;
				}
			}
		}
		//Display the info
		for (int i = 0; i < counter; i++)
		{
			
			System.out.println("----------------------------------------");
			System.out.println("Match Found: " + list[index[i]-1] + " " + list[index[i]] + " " + list[index[i]+1]);
			player[i].print();
			player[i].play();
			
		}	
	}


	


}