package program3;


public class Wave extends WavePlayer implements Sounds{

	protected String title;
	public Wave() {
		// TODO Auto-generated constructor stub
	}
	public void play(){	
		super.play();
}
	public void print(){

				System.out.println("Title:" + this.title);
				System.out.println("FileName: "+ this.filename);
				
	}
	public void setTitle(String title){
		this.title = title;
	}
	public String getTitle(){
		return title;
	}
	public String getFileName()
	{
		// TODO Auto-generated method stub
		return filename;
	}

	
	public void setFileName(String string)
	{
		// TODO Auto-generated method stub
		filename = string;
	}
}
